import java.util.Scanner;

public class FizzBuzz {
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);
		int start = scanner.nextInt();
		int end = scanner.nextInt();
		for (; start <= end; start++) {
			String output = "";
			if (start % 3 == 0) output += "Fizz";
			if (start % 5 == 0) output += "Buzz";
			System.out.println(output.equals("") ? start : output);
		}
	}
}
