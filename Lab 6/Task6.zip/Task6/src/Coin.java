import java.util.Random;

public class Coin {
	private String sideUp;

	public Coin(){
		toss();
	}

	public void toss() {
		Random random = new Random();
		sideUp = random.nextInt(0, 2) == 0 ? "heads" : "tails";
	}

	public String getSideUp() {
		return sideUp;
	}
}
