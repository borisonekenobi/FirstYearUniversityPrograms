import java.util.Objects;

public class CoinTossSimulator {
	public static void main (String[] args) {
		Coin coin = new Coin();
		System.out.println("The side initially facing up: " + coin.getSideUp());
		System.out.println("Now I will toss the coin 10 times.");
		int countHeads = 0;
		int countTails = 0;
		for (int i = 0; i < 10; i++) {
			coin.toss();
			if (Objects.equals(coin.getSideUp(), "heads")) countHeads++;
			else countTails++;
			System.out.println("Toss:   " + coin.getSideUp());
		}
		System.out.println("Total Heads: " + countHeads);
		System.out.println("Total Tails: " + countTails);
	}
}
