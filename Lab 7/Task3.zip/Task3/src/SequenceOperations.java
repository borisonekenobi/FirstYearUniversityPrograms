public class SequenceOperations {
	public static double getTotal(double[] nums) {
		double sum = 0;
		for (double num : nums) {
			sum += num;
		}
		return sum;
	}

	public static double getAverage(double[] nums) {
		double sum = 0;
		for (double num : nums) {
			sum += num;
		}
		return Double.parseDouble(String.format("%.2f", sum / nums.length));
	}

	public static double getHighest(double[] nums) {
		double max = nums[0];
		for (double num : nums) {
			max = Math.max(max, num);
		}
		return max;
	}

	public static double[] getReverse(double[] nums) {
		double[] reversed = new double[nums.length];
		for (int i = nums.length - 1; i >= 0; i--) {
			reversed[nums.length - i - 1] = nums[i];
		}
		return  reversed;
	}
}
