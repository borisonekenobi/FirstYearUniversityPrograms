import java.util.Arrays;

public class Task3Demo {
	public static void main (String[] args) {
		double[] nums = new double[] {3.0, 2.4, 6.0, 2.0, 4.0, 5.1, 7.2};
		System.out.println("Processing the array: " + Arrays.toString(nums));
		System.out.println("Total: " + SequenceOperations.getTotal(nums));
		System.out.println("Average: " + SequenceOperations.getAverage(nums));
		System.out.println("Highest value: " + SequenceOperations.getHighest(nums));
		System.out.println("Array Reverse: " + Arrays.toString(SequenceOperations.getReverse(nums)));
	}
}
