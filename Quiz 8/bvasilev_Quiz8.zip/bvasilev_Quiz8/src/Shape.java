public class Shape {
	public double getArea() {
		return 0;
	}
}
