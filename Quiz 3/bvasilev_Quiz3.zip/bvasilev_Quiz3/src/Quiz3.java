import java.util.Scanner;

public class Quiz3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in); //Define a new Scanner object

        System.out.print("Enter a value for feet: "); //Prompt user to input a number
        double feet =  //Parse
                input.nextDouble();

        System.out.println(feet + " feet is " + feet * 0.305 + " meters");
    }
}
