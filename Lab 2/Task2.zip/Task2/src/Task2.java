public class Task2 {
    // Starting point of program
    public static void main(String[] args) {
        // Define variables
        String name;
        int age;
        double annualPay;

        // Initialize variables
        name = "Boris Vasilev";
        age = 18;
        annualPay = 6_208_585.44;

        // Print
        System.out.println("My name is " + name + ", my age is " + age + " and I hope to earn $" + annualPay + " per year.");
    }
}
