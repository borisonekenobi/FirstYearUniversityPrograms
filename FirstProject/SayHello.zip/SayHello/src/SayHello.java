/*Each Java program must have at least one class.
Note that each program should have an execution points
Here we have multiple comment lines*/


import java.util.Arrays;

public class SayHello {
    public static void main(String[] args) { //This is the method header
        //I need to display welcome message
        System.out.println("Welcome to ES1036a!");
    }
}
