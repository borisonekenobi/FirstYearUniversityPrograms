public class Quiz2 {
    public static void main(String[] args) {
        String courseNumber;
        String studentName;
        int section;

        courseNumber = "ES1036A";
        studentName = "Boris Vasilev";
        section = 1;

        System.out.println("My name is " + studentName + ", I am taking the " + courseNumber + " course section 00" + section);
    }
}
