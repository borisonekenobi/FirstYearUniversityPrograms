public class Dog extends Animal { // class Dog which inherits from the class Animal
	public String say () { // overrides the method say()
		return "arf-arf"; // returns the string "arf-arf"
	}
}
