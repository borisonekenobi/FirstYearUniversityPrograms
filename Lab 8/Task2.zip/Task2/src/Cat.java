public class Cat extends Animal { // class Cat which inherits from the class Animal
	public String say () { // overrides the method say()
		return "meow-meow"; // returns the string "meow-meow"
	}
}
