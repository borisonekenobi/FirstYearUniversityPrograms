public class Animal { // Java class Animal
	public String say() { // method say()
		return ""; // returns empty string
	}
}
