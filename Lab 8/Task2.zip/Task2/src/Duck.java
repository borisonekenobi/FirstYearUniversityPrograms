public class Duck extends Animal { // class Duck which inherits from the class Animal
	public String say () { // overrides the method say()
		return "quack-quack"; // returns the string "quack-quack"
	}
}
