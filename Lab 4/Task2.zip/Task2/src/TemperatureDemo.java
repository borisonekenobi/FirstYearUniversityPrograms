import java.util.Scanner;

public class TemperatureDemo {
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the Fahrenheit temperature: ");
		double ftemp = scanner.nextDouble();

		Temperature temperature = new Temperature(ftemp);

		System.out.println("Celsius: " + temperature.getCelsius());
		System.out.println("Kelvin: " + temperature.getKelvin());
	}
}
