import java.util.Scanner;

public class CylinderDemo {
	public static void main (String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter the radius of a cylinder: ");
		double radius = scanner.nextDouble();

		System.out.print("Enter the height of a cylinder: ");
		double height = scanner.nextDouble();

		Cylinder cylinder = new Cylinder();

		cylinder.setRadius(radius);
		cylinder.setHeight(height);

		System.out.println("The cylinder's radius is " + cylinder.getRadius());
		System.out.println("The cylinder's height is " + cylinder.getHeight());
		System.out.println("The cylinder's volume is " + cylinder.getVolume());
		System.out.println("The cylinder's curved surface area is " + cylinder.getCurvedSurfaceArea());
		System.out.println("The cylinder's total surface area is " + cylinder.getTotalSurfaceArea());
	}
}
